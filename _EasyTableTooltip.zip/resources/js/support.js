define([], function () {
    'use strict';
    
	return {
		snapshot: false,
		export: false,
		exportData : false
	};
});