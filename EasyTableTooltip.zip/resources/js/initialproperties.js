define([], function () {
    'use strict';
    
	return {
		eTableTooltip: {
			dimensionsList: []
		}
	};
});